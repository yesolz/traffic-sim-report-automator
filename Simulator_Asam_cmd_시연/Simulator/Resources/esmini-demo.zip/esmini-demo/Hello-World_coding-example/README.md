## esmini Hello World

**main.cpp** is a minimalistic scenario player application

**esmini-player.py** is the same application wrapped for Python using ctypes binding

For more information and further examples, see User Guide [Hello World programming tutorial](https://esmini.github.io/#_hello_world_programming_tutorial).
